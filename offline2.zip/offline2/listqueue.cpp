#include "queue.h"
#include <iostream>
using namespace std;

// Constructor implementation
ListQueue::ListQueue()
{
    // TODO: Initialize front_node and rear_node
    front_node = NULL;
    rear_node = NULL;
    // TODO: Initialize current_size to 0
    current_size = 0;
}

// Destructor implementation
ListQueue::~ListQueue()
{
    // TODO: Deallocate all nodes in the linked list
    // TODO: Consider using the clear() method
    clear();
}

// Enqueue implementation (add an item at the rear of the queue)
void ListQueue::enqueue(int item)
{
    // TODO: Create a new node with the given item
    Node *newN = new Node(item);
    if (rear_node == NULL)
    {
        front_node = rear_node = newN;
    }
    // TODO: Link the new node to the rear
    else
    {
        rear_node->next = newN;
        // TODO: Update the rear_node
        rear_node = newN;
    }

    // TODO: Increment the current size
    current_size++;
}

// Dequeue implementation (remove an item from the front of the queue)
int ListQueue::dequeue()
{
    // TODO: Check if the queue is empty, display error message if it is
    if (empty())
    {
        cout << "Queue is empty " << endl;
        return -1;
    }
    // TODO: Store the data from the front node
    int value;
    Node *temp = front_node;
    value = temp->data;

    // TODO: Update the front pointer to the next node
    front_node = front_node->next;

    // TODO: Update the rear pointer if the queue becomes empty
    if (front_node == nullptr)
    {
        rear_node = nullptr;
    }
    // TODO: Delete the old front node
    delete temp;
    current_size--;
    // TODO: Decrement current_size
    // TODO: Return the stored data
    return value;
}

// Clear implementation (delete all elements)
void ListQueue::clear()
{

    // TODO: Traverse the linked list and delete each node
    while (front_node != NULL)
    {
        Node *curN = front_node;
        front_node = front_node->next;
        delete curN;
    }
    // TODO: Reset front and rear pointer

    rear_node = NULL;
    // TODO: Reset current_size to 0
    current_size = 0;
}

// Size implementation (return the current number of elements)
int ListQueue::size() const
{
    // TODO: Return the current size (current_size)
    return current_size;
}

// Front implementation (get the element at the front of the queue)
int ListQueue::front() const
{
    // TODO: Check if the queue is empty, display error message if it is

    if (empty())
    {
        cout << "Queue is empty" << endl;
        return -1;
    } // TODO: Return the data from the front node without removing it
    return front_node->data;
}

// Back implementation (get the element at the back of the queue)
int ListQueue::back() const
{
    if (empty())
    {
        cout << "Queue is empty" << endl;
        return -1;
    }
    // TODO: Check if the queue is empty, display error message if it is
    // TODO: Return the data from the back node without removing it
    return rear_node->data;
}

// Empty implementation (check if the queue is empty)
bool ListQueue::empty() const
{
    if (front_node == NULL)
        return true;
    else
        return false;
    // TODO: Return whether front is nullptr
}

// Print implementation (print elements from front to rear)
string ListQueue::toString() const
{
    string s = "<";
    Node *curN = front_node;

    // TODO: Convert queue to a string representation in the format: <elem1, elem2, ..., elemN|
    // TODO: Traverse the linked list from front
    while (curN != NULL)
    {
        s += to_string(curN->data);
        if (curN->next != NULL)
        {
            s += ", ";
        }
        curN = curN->next;
    }
    s += "|";
    return s;
}
