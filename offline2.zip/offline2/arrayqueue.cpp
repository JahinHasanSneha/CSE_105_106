#include "queue.h"
#include <iostream>
using namespace std;
// Constructor implementation
ArrayQueue::ArrayQueue(int initial_capacity)
{
    if (initial_capacity < 2)
        initial_capacity = 2;
    // TODO: Initialize data members (data, capacity, front_idx, rear_idx)

    capacity = initial_capacity; // Maximum number of elements the array can currently hold
    front_idx = 0;               // Index of the front element
    rear_idx = -1;               // Index of the rear element

    // TODO: Allocate memory for the array with the specified initial capacity
    data = new int[capacity];
}

// Destructor implementation
ArrayQueue::~ArrayQueue()
{
    delete[] data;
    data = NULL;
    // TODO: Free the dynamically allocated memory for the array
}

// Enqueue implementation (add an item to the rear of the queue)
void ArrayQueue::enqueue(int item)
{
    // TODO: Check if the array is full
    if (rear_idx == capacity - 1)
    {
        resize(capacity * 2);
    }
    // TODO: If full, resize the array to double its current capacity
    // TODO: Add the new element to the rear of the queue
    data[++rear_idx] = item;
}

// Dequeue implementation (remove an item from the front of the queue)
int ArrayQueue::dequeue()
{
    if (empty())
    {
        cout << "Queue is empty" << endl;
        return -1;
    }
    // TODO: Check if the queue is empty, display error message if it is
    // TODO: Update front index
    int dequeued = data[front_idx];
    for (int i = 0; i < rear_idx; i++)
    {
        data[i] = data[i + 1];
    }
    rear_idx = rear_idx - 1;
    // TODO: If the array is less than 25% full, resize it to half its current capacity (but not less than 2)
    if (capacity > 2 && size() < capacity / 4)
    {
        int new_capacity = capacity / 2;
        if (new_capacity < 2)
            new_capacity = 2;
        resize(new_capacity);
    }
    // TODO: Return the dequeued element
    return dequeued;
}

// Clear implementation
void ArrayQueue::clear()
{
    // TODO: Reset the queue to be empty (reset capacity, front_idx, rear_idx, data)
    delete[] data;
    capacity = 2;
    rear_idx = -1;
    front_idx = 0;
    data = new int[capacity];
}

// Size implementation
int ArrayQueue::size() const
{
    // TODO: Return the number of elements currently in the queue
    return rear_idx + 1;
}

// Front implementation
int ArrayQueue::front() const
{
    // TODO: Check if the queue is empty, display error message if it is
    if (empty())
    {
        cout << "Oueue is empty" << endl;
        return -1;
    }

    // TODO: Return the element at the front of the queue without removing it
    return data[front_idx];
}

// Back implementation (get the element at the back of the queue)
int ArrayQueue::back() const
{
    // TODO: Check if the queue is empty, display error message if it is
    if (empty())
    {
        cout << "Oueue is empty" << endl;
        return -1;
    }

    // TODO: Return the element at the back of the queue without removing it
    return data[rear_idx];
}

// Empty implementation
bool ArrayQueue::empty() const
{
    // TODO: Return whether the queue is empty
    if (rear_idx < 0)
        return true;
    else
        return false;
}

// Print implementation
string ArrayQueue::toString() const
{
    // TODO: Convert queue to a string representation in the format: <elem1, elem2, ..., elemN|
    string s = "<";
    for (int i = 0; i < size(); i++)
    {
        s += to_string(data[i]);
        if (i != size() - 1)
        {
            s += ",";
        }
    }
    s += "|";
    return s;
}

// Resize implementation
void ArrayQueue::resize(int new_capacity)
{
    if (new_capacity < 2)
        new_capacity = 2;
    // TODO: Create a new array with the new capacity
    int *new_array = new int[new_capacity];
    // TODO: Copy elements from the old array to the new array
    for (int i = 0; i < size(); i++)
    {
        new_array[i] = data[i];
    }
    // TODO: Delete the old array
    delete[] data;
    // TODO: Update the data pointer and capacity
    data = new_array;
    capacity = new_capacity;
    // TODO: Update front and rear indices
}

int ArrayQueue::getCapacity() const
{
    return capacity;

    // TODO: Return the current capacity of the queue
}